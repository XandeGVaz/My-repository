Arquivo zip gerado em: 16/09/2023 17:31:35 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: TP01 - Editor de Textos (Trabalho Prático: vale nota)