Arquivo zip gerado em: 17/11/2023 18:27:27 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: TP02 - Big Brother (Trabalho Prático: vale nota)