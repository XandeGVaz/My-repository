#include <stdio.h>
#include <stdbool.h>

// Define the possible moves for a knight
int moveX[8] = {2, 1, -1, -2, -2, -1,  1,  2};
int moveY[8] = {1, 2,  2,  1, -1, -2, -2, -1};

// Function to check if the position is within the board and not yet visited
bool isSafe(int x, int y, int n, int board[n][n]) {
    return (x >= 0 && y >= 0 && x < n && y < n && board[x][y] == -1);
}

// Function to print the board
void printBoard(int n, int board[n][n]) {
    for (int x = 0; x < n; x++) {
        for (int y = 0; y < n; y++) {
            printf("%2d ", board[x][y]);
        }
        printf("\n");
    }
}

// Function to solve the Knight's Tour problem using backtracking
bool solveKnightTour(int n, int board[n][n], int x, int y, int moveCount) {
    if (moveCount == n * n) {
        return true; // All squares are visited
    }

    for (int i = 0; i < 8; i++) {
        int nextX = x + moveX[i];
        int nextY = y + moveY[i];
        if (isSafe(nextX, nextY, n, board)) {
            board[nextX][nextY] = moveCount;
            if (solveKnightTour(n, board, nextX, nextY, moveCount + 1)) {
                return true;
            } else {
                board[nextX][nextY] = -1; // Backtracking
            }
        }
    }

    return false;
}

int main() {
    int n, startX, startY;


    // Input the size of the board
    printf("Enter the size of the board: ");
    scanf("%d", &n);


   
 // Input the initial position of the knight
    printf("Enter the starting X position: ");
    scanf("%d", &startX);
	printf("Enter the starting Y position: ");
    scanf("%d", &startY);


    // Initialize the board
    int board[n][n];
    for (int x = 0; x < n; x++) {
        for (int y = 0; y < n; y++) {
            board[x][y] = -1;
        }
    }

    // Start the knight's tour from the initial position
    board[startX][startY] = 0;

    if (solveKnightTour(n, board, startX, startY, 1)) {
        printf("Solution exists:\n");
        printBoard(n, board);
    } else {
        printf("No solution exists.\n");
    }

    return 0;
}

